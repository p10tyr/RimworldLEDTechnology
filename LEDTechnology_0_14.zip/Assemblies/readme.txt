Set visual studio to build out here so you can start stop game easily.
Bleeding edge does not contain any DLL's

Please select a branch and download ZIP from Compiled or go to steam.
http://steamcommunity.com/sharedfiles/filedetails/?id=760900903
